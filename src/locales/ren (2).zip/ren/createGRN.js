export default {
  grn_title: "Goods Receipt Note (GRN)",
  grn_back: "Back to Orders",
  grn_no: "GRN No",

  grn_supplier: "Supplier",
  grn_received_by: "Received By",
  grn_date: "GRN Date",

  grn_product: "Product",
  grn_uom: "UOM",
  grn_ordered: "Ordered",
  grn_received: "Received",
  grn_rejected: "Rejected",
  grn_status: "Status",

  grn_short: "Short",
  grn_perfect: "Perfect",

  grn_summary: "GRN Summary",
  grn_total_items: "Total Items",
  grn_total_ordered: "Total Ordered Qty",
  grn_total_received: "Total Received Qty",
  grn_total_rejected: "Total Rejected Qty",

  grn_remarks: "GRN Remarks",
  grn_remarks_placeholder: "Enter remarks (optional)",

  grn_tap_sign: "Tap to Sign",

  grn_save: "Save Draft",
  grn_confirm: "Confirm GRN",
  grn_download: "Download PDF",

  grn_success: "GRN Confirmed — Inventory successfully updated",
};