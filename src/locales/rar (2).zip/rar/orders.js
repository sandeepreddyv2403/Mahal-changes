export default {
  resmy_orders: "طلباتي",
  resorders_subtitle: "عرض وإدارة جميع طلبات المطعم",

  resshow_normal_orders: "عرض الطلبات العادية",
  resshow_recurring_orders: "عرض الطلبات المتكررة",

  ressearch_order: "ابحث برقم الطلب",
  resall_status: "كل الحالات",
  resplaced: "تم الطلب",
  resconfirmed: "تم التأكيد",
  resout_for_delivery: "قيد التوصيل",
  resdelivered: "تم التوصيل",
  resrejected: "مرفوض",

  resorders_found: "طلبات",

  resdate: "التاريخ",
  resproducts: "المنتجات",
  restotal: "الإجمالي",
  resdaily: "يومي",
  resaction: "إجراء",

  resno_orders: "لا توجد طلبات",

  resmake_daily: "اجعلها يومية",
  respause: "إيقاف",
  resview: "عرض",
  resmodify: "تعديل",
  rescancel: "إلغاء",

  resrecurring_setup: "إعداد الطلب المتكرر",
  resfrequency: "التكرار",
  resweekly: "أسبوعي",
  resselect_days: "اختر الأيام",
  resstart_date: "تاريخ البداية",
  resend_date: "تاريخ النهاية",
  resactivate: "تفعيل",
resplaced: "تم الطلب",
  resaccepted: "تم القبول",
  respacked: "تم التجهيز",
  resout_for_delivery: "قيد التوصيل",
  resdelivered: "تم التوصيل",
  resrejected: "مرفوض",
};